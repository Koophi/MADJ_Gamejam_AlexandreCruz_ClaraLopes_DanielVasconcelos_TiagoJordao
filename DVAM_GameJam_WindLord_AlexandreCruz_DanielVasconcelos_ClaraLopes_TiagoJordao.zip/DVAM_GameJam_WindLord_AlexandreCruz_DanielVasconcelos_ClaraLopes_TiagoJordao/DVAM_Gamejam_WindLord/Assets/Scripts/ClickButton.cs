using UnityEngine;

public class ClickButton : MonoBehaviour
{
    public void Click()
    {
        GameManager.instance.AddClick();
    }
}
