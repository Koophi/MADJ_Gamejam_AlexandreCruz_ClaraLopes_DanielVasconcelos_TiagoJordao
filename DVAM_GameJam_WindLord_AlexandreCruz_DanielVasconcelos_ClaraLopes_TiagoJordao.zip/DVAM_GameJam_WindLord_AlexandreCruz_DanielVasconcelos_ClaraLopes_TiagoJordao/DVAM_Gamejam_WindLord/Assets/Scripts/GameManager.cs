using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    [Header("Currency")]
    public float power = 0;

    [Header("Stats")]
    public float powerPerClick = 1;
    public float powerPerSecond = 1;

    [Header("UI")]
    public TMP_Text powerText;
    public TMP_Text perClickText;
    public TMP_Text perSecondText;

    private void Awake()
    {
        instance = this;
    }

    void Start()
    {
        InvokeRepeating(nameof(AddPassiveIncome), 1f, 1f);
        UpdateUI();
    }

    void AddPassiveIncome()
    {
        power += powerPerSecond;
        UpdateUI();
    }

    public void AddClick()
    {
        power += powerPerClick;
        UpdateUI();
    }

    public void UpdateUI()
    {
        powerText.text = "Power: " + power.ToString("F0");
        perClickText.text = "Power Per Click: " + powerPerClick.ToString("F1");
        perSecondText.text = "Power Per Second: " + powerPerSecond.ToString("F1");
    }
}
