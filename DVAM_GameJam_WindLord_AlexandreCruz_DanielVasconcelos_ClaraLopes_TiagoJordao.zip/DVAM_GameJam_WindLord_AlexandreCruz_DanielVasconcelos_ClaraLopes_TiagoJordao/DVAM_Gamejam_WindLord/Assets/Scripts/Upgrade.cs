using UnityEngine;
using TMPro;

public class Upgrade : MonoBehaviour
{
    [Header("Info")]
    public string upgradeName;

    [Header("Stats")]
    public float baseCost = 10f;
    public float costMultiplier = 1.15f;
    public int amountOwned = 0;

    [Header("Power Gains")]
    public float addPerSecond = 0f;
    public float addPerClick = 0f;

    [Header("UI")]
    public TMP_Text costText;
    public TMP_Text amountText;

    private float currentCost;

    void Start()
    {
        currentCost = baseCost;
        UpdateUI();

        Debug.Log($"[UPGRADE INIT] {upgradeName} inicializado com custo {currentCost}");
    }

    public void Buy()
    {
        Debug.Log($"[CLICK DETECTADO] Botão de upgrade clicado: {upgradeName}");

        if (GameManager.instance == null)
        {
            Debug.LogError($"[ERRO] GameManager.instance é NULL! O upgrade {upgradeName} não consegue aceder ao power.");
            return;
        }

        Debug.Log($"[CHECK] Power atual: {GameManager.instance.power} | Custo: {currentCost}");

        if (GameManager.instance.power >= currentCost)
        {
            Debug.Log($"[COMPRA] Compra efetuada: {upgradeName}");

            GameManager.instance.power -= currentCost;
            amountOwned++;

            GameManager.instance.powerPerSecond += addPerSecond;
            GameManager.instance.powerPerClick += addPerClick;

            currentCost *= costMultiplier;

            UpdateUI();
            GameManager.instance.UpdateUI();

            Debug.Log($"[COMPRA OK] {upgradeName} agora tem {amountOwned} unidades. Novo custo: {currentCost}");
        }
        else
        {
            Debug.Log($"[FALHOU] Não tens power suficiente para comprar {upgradeName}");
        }
    }

    void UpdateUI()
    {
        if (costText != null)
            costText.text = "Cost: " + currentCost.ToString("F0");
        else
            Debug.LogError($"[ERRO UI] costText está NULL no upgrade {upgradeName}");

        if (amountText != null)
            amountText.text = "Owned: " + amountOwned;
        else
            Debug.LogError($"[ERRO UI] amountText está NULL no upgrade {upgradeName}");
    }
}
